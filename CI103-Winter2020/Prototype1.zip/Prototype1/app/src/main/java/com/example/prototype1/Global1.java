package com.example.prototype1;

import android.app.Application;

public class Global1 extends Application {
    private String Theme = "Default";
    public String GetTheme() {
        return Theme;
    }
    public void SetTheme(String str) {
        Theme = str;
    }

    private String[] News = new String[]{"","","","","", ""};
    private int i = 0;
    public String[] GetNews() {
        return News;
    }
    public Boolean SetNews(String str){
        if (i < 5) {
            News[i] = str;
            i++;
            return true;
        }
        else return false;
    }
    public void DelNews(int x){
        i--;
        while( x < 5 ){
            News[x] = News[x+1];
            x++;
        }
    }
}