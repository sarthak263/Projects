package com.example.prototype1;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Login extends AppCompatActivity {
    public void onCreate(Bundle savedInstanceState) {
        final Global1 global1 = ((Global1) getApplicationContext());
        String theme = global1.GetTheme();
        super.onCreate(savedInstanceState);
        if(theme.compareTo("Default") == 0){
            setTheme(R.style.AppTheme);
        }
        else if(theme.compareTo("Red") == 0){
            setTheme(R.style.RedTheme);
        }
        else if(theme.compareTo("Pink") == 0){
            setTheme(R.style.PinkTheme);
        }
        else if(theme.compareTo("Black") == 0){
            setTheme(R.style.BlackTheme);
        }
        else if(theme.compareTo("White") == 0){
            setTheme(R.style.WhiteTheme);
        }
        else if(theme.compareTo("Green") == 0){
            setTheme(R.style.GreenTheme);
        }
        else if(theme.compareTo("Blue") == 0){
            setTheme(R.style.BlueTheme);
        }
        else if(theme.compareTo("Purple") == 0){
            setTheme(R.style.PurpleTheme);
        }
        else if(theme.compareTo("Yellow") == 0){
            setTheme(R.style.YellowTheme);
        }
        setContentView(R.layout.login);
        Button enter = (Button) findViewById(R.id.Enter);
        enter.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent1 = new Intent(view.getContext(), MainActivity.class);
                EditText userField = (EditText)findViewById(R.id.Username);
                EditText passField = (EditText)findViewById(R.id.Password);
                String username = userField.getText().toString();
                String password = passField.getText().toString();
                if( username.equals("Username") & password.equals("Password") ){
                    startActivityForResult(intent1, 0);
                } else {
                    TextView InvalidCredentials = (TextView)findViewById(R.id.Incorrect);
                    InvalidCredentials.setVisibility(View.VISIBLE);
                }
            }
        });
    }
}
