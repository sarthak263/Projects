package com.example.prototype1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SecondScreen extends AppCompatActivity {
    public void onCreate(Bundle savedInstanceState) {
        final Global1 global1 = ((Global1) getApplicationContext());
        String theme = global1.GetTheme();
        super.onCreate(savedInstanceState);
        if(theme.compareTo("Default") == 0){
            setTheme(R.style.AppTheme);
        }
        else if(theme.compareTo("Red") == 0){
            setTheme(R.style.RedTheme);
        }
        else if(theme.compareTo("Pink") == 0){
            setTheme(R.style.PinkTheme);
        }
        else if(theme.compareTo("Black") == 0){
            setTheme(R.style.BlackTheme);
        }
        else if(theme.compareTo("White") == 0){
            setTheme(R.style.WhiteTheme);
        }
        else if(theme.compareTo("Green") == 0){
            setTheme(R.style.GreenTheme);
        }
        else if(theme.compareTo("Blue") == 0){
            setTheme(R.style.BlueTheme);
        }
        else if(theme.compareTo("Purple") == 0){
            setTheme(R.style.PurpleTheme);
        }
        else if(theme.compareTo("Yellow") == 0){
            setTheme(R.style.YellowTheme);
        }
        global1.SetTheme(theme);
        setContentView(R.layout.second_screen);
        final TextView Msg = findViewById(R.id.Message);
        Button switch2 = (Button) findViewById(R.id.newscreen);
        Button Default = (Button) findViewById(R.id.Default);
        Button Red = (Button) findViewById(R.id.Red);
        Button Pink = (Button) findViewById(R.id.Pink);
        Button Black = (Button) findViewById(R.id.Black);
        Button White = (Button) findViewById(R.id.White);
        Button Blue = (Button) findViewById(R.id.Blue);
        Button Green = (Button) findViewById(R.id.Green);
        Button Yellow = (Button) findViewById(R.id.Yellow);
        Button Purple = (Button) findViewById(R.id.Purple);
        Default.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                global1.SetTheme("Default");
                Msg.setText("The theme will change to Default when you switch screens");
            }
        });
        Red.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                global1.SetTheme("Red");
                Msg.setText("The theme will change to Red when you switch screens");
            }
        });
        Pink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                global1.SetTheme("Pink");
                Msg.setText("The theme will change to Pink when you switch screens");
            }
        });
        Black.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                global1.SetTheme("Black");
                Msg.setText("The theme will change to Black when you switch screens");
            }
        });
        White.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                global1.SetTheme("White");
                Msg.setText("The theme will change to White when you switch screens");
            }
        });
        Blue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                global1.SetTheme("Blue");
                Msg.setText("The theme will change to Blue when you switch screens");
            }
        });
        Green.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                global1.SetTheme("Green");
                Msg.setText("The theme will change to Green when you switch screens");
            }
        });
        Yellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                global1.SetTheme("Yellow");
                Msg.setText("The theme will change to Yellow when you switch screens");
            }
        });
        Purple.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                global1.SetTheme("Purple");
                Msg.setText("The theme will change to Purple when you switch screens");
            }
        });
        switch2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent2 = new Intent(view.getContext(), MainActivity.class);
                startActivityForResult(intent2, 0);
            }
        });
    }
}

