package com.example.prototype1;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.SearchView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;



public class MainActivity extends AppCompatActivity {
    TextView searchfor;
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        final MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options_menu, menu);
        SearchView searchView =
                (SearchView) menu.findItem(R.id.searchable).getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                searchfor = (TextView)findViewById(R.id.SearchResult);
                new GetResults().execute(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_settings:
                Intent intent = new Intent(this,SecondScreen.class);
                this.startActivity(intent);
                return true;
            case R.id.action_new:
                Intent intent2 = new Intent(this, NewStock.class);
                this.startActivity(intent2);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        final Global1 global1 = ((Global1) getApplicationContext());
        String theme = global1.GetTheme();
        super.onCreate(savedInstanceState);
        if(theme.compareTo("Default") == 0){
            setTheme(R.style.AppTheme);
        }
        else if(theme.compareTo("Red") == 0){
            setTheme(R.style.RedTheme);
        }
        else if(theme.compareTo("Pink") == 0){
            setTheme(R.style.PinkTheme);
        }
        else if(theme.compareTo("Black") == 0){
            setTheme(R.style.BlackTheme);
        }
        else if(theme.compareTo("White") == 0){
            setTheme(R.style.WhiteTheme);
        }
        else if(theme.compareTo("Green") == 0){
            setTheme(R.style.GreenTheme);
        }
        else if(theme.compareTo("Blue") == 0){
            setTheme(R.style.BlueTheme);
        }
        else if(theme.compareTo("Purple") == 0){
            setTheme(R.style.PurpleTheme);
        }
        else if(theme.compareTo("Yellow") == 0){
            setTheme(R.style.YellowTheme);
        }
        setContentView(R.layout.activity_main);
    }
    public class GetResults extends AsyncTask<String, TextView, String> {
        @Override
        protected String doInBackground(String... query) {
            HttpURLConnection herokuConnection = null;
            String output = "";
            try {
                URL herokuURL = new URL(String.format("https://ci101-prototype.herokuapp.com/news/search/%s", query[0]));
                herokuConnection = (HttpURLConnection) herokuURL.openConnection();
                int herokuCode = herokuConnection.getResponseCode();
                if (herokuCode == 200) {
                    InputStream herokuIn = new BufferedInputStream(herokuConnection.getInputStream());
                    if (herokuIn != null) {
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(herokuIn));
                        String line = "";
                        while ((line = bufferedReader.readLine()) != null) output += line;
                        JSONArray JSONArray = new JSONArray(output);
                        output = "";
                        for(int i=0; i < JSONArray.length(); i++){
                            try{
                              JSONObject JSONobject = JSONArray.getJSONObject(i);
                              JSONArray articles = JSONobject.getJSONArray("articles");
                              for(int j=0; j < articles.length(); j++){
                                  JSONObject articletitle = articles.getJSONObject(j);
                                  String Title = articletitle.getString("title");
                                  String Hyperlink = articletitle.getString("url");
                                  String Result = String.format("<a href='%s'>%s</a><br/><br/>", Hyperlink, Title);
                                  output += Result;
                              }
                            }catch (JSONException e){
                                e.printStackTrace();
                                output = "JSON1";
                            }
                        }
                    }
                    herokuIn.close();
                }
                return output;
            } catch (MalformedURLException e) {
                e.printStackTrace();
                output = "Malformed";
            } catch (IOException e) {
                e.printStackTrace();
                output = "IO";
            } catch (JSONException e) {
                e.printStackTrace();
                output= "JSON";
            } finally {
                herokuConnection.disconnect();
            }
            return output;
        }
        @Override
        protected void onPostExecute(String output) {
            searchfor.setText(Html.fromHtml(output));
            searchfor.setMovementMethod(LinkMovementMethod.getInstance());
            super.onPostExecute(output);
        }
    }
}
