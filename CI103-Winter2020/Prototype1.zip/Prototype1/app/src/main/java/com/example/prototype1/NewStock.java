package com.example.prototype1;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;



public class NewStock extends Activity {
    public void onCreate(Bundle savedInstanceState) {
        final Global1 global1 = ((Global1) getApplicationContext());
        String theme = global1.GetTheme();
        super.onCreate(savedInstanceState);
        if(theme.compareTo("Default") == 0){
            setTheme(R.style.AppTheme);
        }
        else if(theme.compareTo("Red") == 0){
            setTheme(R.style.RedTheme);
        }
        else if(theme.compareTo("Pink") == 0){
            setTheme(R.style.PinkTheme);
        }
        else if(theme.compareTo("Black") == 0){
            setTheme(R.style.BlackTheme);
        }
        else if(theme.compareTo("White") == 0){
            setTheme(R.style.WhiteTheme);
        }
        else if(theme.compareTo("Green") == 0){
            setTheme(R.style.GreenTheme);
        }
        else if(theme.compareTo("Blue") == 0){
            setTheme(R.style.BlueTheme);
        }
        else if(theme.compareTo("Purple") == 0){
            setTheme(R.style.PurpleTheme);
        }
        else if(theme.compareTo("Yellow") == 0){
            setTheme(R.style.YellowTheme);
        }
        setContentView(R.layout.new_stock);
        Button back = (Button)findViewById(R.id.back);
        Button submit = (Button) findViewById(R.id.submitStock);
        final EditText input = (EditText)findViewById(R.id.enterStock);
        final TextView error = (TextView)findViewById(R.id.error);
        final TextView full = (TextView)findViewById(R.id.Full);
        final TextView Source1 = (TextView)findViewById(R.id.Source1);
        final TextView Source2 = (TextView)findViewById(R.id.Source2);
        final TextView Source3 = (TextView)findViewById(R.id.Source3);
        final TextView Source4 = (TextView)findViewById(R.id.Source4);
        final TextView Source5 = (TextView)findViewById(R.id.Source5);
        final TextView[] Sources = {Source1, Source2, Source3, Source4, Source5};
        for(int i = 0; i < 5; i++){
            String[] news = global1.GetNews();
            Sources[i].setText(news[i]);
        }
        submit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Boolean New;
                String inputString = input.getText().toString();
                if (inputString.isEmpty()) {
                    error.setVisibility(View.VISIBLE);
                    return;
                } else {
                    New = global1.SetNews(inputString);
                    if (New == false) {
                        full.setVisibility(View.VISIBLE);
                    }
                    else {
                        for(int i = 0; i < 5; i++){
                            String[] news = global1.GetNews();
                            Sources[i].setText(news[i]);
                        }
                    }
                }
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(v.getContext(), MainActivity.class);
                startActivityForResult(intent1, 0);
            }
        });
        Source1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                global1.DelNews(0);
                for(int i = 0; i < 5; i++){
                    String[] news = global1.GetNews();
                    Sources[i].setText(news[i]);
                }
            }
        });
        Source2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                global1.DelNews(1);
                for(int i = 0; i < 5; i++){
                    String[] news = global1.GetNews();
                    Sources[i].setText(news[i]);
                }
            }
        });
        Source3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                global1.DelNews(2);
                for(int i = 0; i < 5; i++){
                    String[] news = global1.GetNews();
                    Sources[i].setText(news[i]);
                }
            }
        });
        Source4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                global1.DelNews(3);
                for(int i = 0; i < 5; i++){
                    String[] news = global1.GetNews();
                    Sources[i].setText(news[i]);
                }
            }
        });
        Source5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                global1.DelNews(4);
                for(int i = 0; i < 5; i++){
                    String[] news = global1.GetNews();
                    Sources[i].setText(news[i]);
                }
            }
        });
    }
}

